#!/usr/bin/env bash

#/etc/init.d/ssh start
/etc/init.d/mysql-ndb-mgm start
# /etc/init.d/portmap start
/etc/init.d/mysql-ndb start
/etc/init.d/mysql start
# /etc/init.d/distcc start
#/etc/init.d/openbsd-inetd start
#/etc/init.d/postfix start
#/etc/init.d/rsync start
#/etc/init.d/samba start
#/etc/init.d/snmpd start
#/etc/init.d/xinetd start
#/etc/init.d/proftpd start
#/etc/init.d/tomcat5.5 start
/etc/init.d/apache2 start
/etc/init.d/rc.local start
/etc/init.d/rmnologin start

#/usr/bin/unrealircd

/bin/bash