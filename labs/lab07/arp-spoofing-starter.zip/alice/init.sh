#!/usr/bin/env bash

node index.js