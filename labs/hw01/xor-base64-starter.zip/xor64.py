from Crypto.Cipher import XOR

''' encrypts the plaintext (utf-8) with a key
    based on the xor cipher algorithm
    and return the ciphertext (base64 encoded)
    (string, string) -> string
'''
def encrypt(key, plaintext):
    ciphertext = plaintext # dummy instruction
    return ciphertext

''' decrypts the ciphertext (base64 encoded) with a key
    based on the xor cipher algorithm
    and returns the plaintext (utf-8)
    (string, string) -> string
'''    
def decrypt(key, ciphertext):
    plaintext = ciphertext # dummy instruction
    return plaintext