import httplib, urlparse, urllib
from md5p import md5, padding

###############
### attack ####
###############

def attack(url, tag, sid, mark): 
    # parameter url is the attack url you construct
    parsedURL = urlparse.urlparse(url)

    # open a connection to the server
    httpconn = httplib.HTTPConnection(parsedURL.hostname, parsedURL.port)

    query = parsedURL.path + "?tag=" + tag + "&sid=" + sid; 

    # issue server-API request
    httpconn.request("GET", query)

    # httpresp is response object containing a status value and possible message
    httpresp = httpconn.getresponse()

    # valid request will result in httpresp.status value 200
    print httpresp.status

    # in the case of a valid request, print the server's message
    print httpresp.read()
    
    # return the url that made the attack successul 
    return(query) # dummy code


#############
### main ####
#############

if __name__ == "__main__":
    url = "http://grades.cms-weblab.utsc.utoronto.ca/"
    tag = "3f1de1c1fd83263f159f6dc284fd51b4"
    sid = "0000000001"
    mark = "100"
    
    print(attack(url, tag, sid, mark))