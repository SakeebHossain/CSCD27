def rc4(key, inputStream):
    ''' returns the RC4 encoding of inputStream based on the key
    (bytes, bytes) -> bytes
    '''
    return inputStream # dummy instruction