from Crypto.Cipher import ARC4
import wave

def encrypt(key_filename, input_filename, output_filename):
    ''' 
    Encrypts the wave input file (input_filename) with the key (key_filename) using the rc4 cipher (from pycrypto)
    and writes the wave output file (output_filename). 
    The wave output file must be a playable wave file.
    (string, string, string) -> None
    '''
    None
    
def decrypt(key_filename, input_filename, output_filename):
    ''' 
    Decrypts the wave input file (input_filename) with the key (key_filename) using the rc4 cipher (from pycrypto)
    and writes the wave output file (output_filename). 
    The wave output file must be a playable wave file. 
    (string, string, string) -> None
    '''
    None
