#include <stdio.h>
#include <string.h>

void func(char *name)
{
    char buf[100];
    strcpy(buf, name);
    printf("Welcome %s\n", buf);
    printf("%p\n",(void*)&buf);
}

int main(int argc, char *argv[])
{
    func(argv[1]);
    return 0;
}